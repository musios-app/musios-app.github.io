// Tests for the Lyrics & Chords scripts. Run with: npm test
// Every lyric below is invented. No real song text belongs in this file or in the repo.
import test from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, writeFileSync, rmSync, readFileSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { deflateRawSync } from "node:zlib";

const scripts = fileURLToPath(new URL("../scripts/", import.meta.url));
const dir = mkdtempSync(join(tmpdir(), "lc-test-"));
test.after(() => rmSync(dir, { recursive: true, force: true }));

const run = (script, args = [], input = "") =>
  spawnSync(process.execPath, [join(scripts, script), ...args], { input, encoding: "utf8", timeout: 60000 });
const file = (name, text) => {
  const path = join(dir, name);
  writeFileSync(path, text);
  return path;
};
const load = (path, ...args) => {
  const r = run("load.mjs", [path, ...args]);
  return { code: r.status, result: JSON.parse(r.stdout) };
};

const sectionsOf = (song) => song.lines.flatMap((l) => l.items.filter((x) => x.type === "tag" && x.name.startsWith("start_of_")).map((x) => x.value));
const commentsOf = (song) => song.lines.flatMap((l) => l.items.filter((x) => x.type === "tag" && x.name === "comment").map((x) => x.value));
const chordsOf = (song) => song.lines.flatMap((l) => l.items.filter((x) => x.type === "chordLyricsPair" && x.chords).map((x) => x.chords));
const lyricLinesOf = (song) =>
  song.lines.map((l) => l.items.filter((x) => x.type === "chordLyricsPair").map((x) => x.lyrics).join("")).filter((t) => t.trim());

const WITH_PERFORMERS = [
  "[Intro]", "Invented words one", "", "[Verse 1: Ann B]", "Made up line two", "Made up line three", "",
  "[Chorus: Ann B & Cal]", "Pretend chorus line", "Pretend chorus again", "", "[Bridge: Cal & Ann B]", "Imaginary bridge line",
].join("\n");

const lyricsOnly = (name, text, ...extra) => load(file(name, text), "--format", "lyrics-only", ...extra);

test("lyrics-only text whose headers name performers loads as real sections", () => {
  const { code, result } = lyricsOnly("performers.txt", WITH_PERFORMERS);
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  assert.deepEqual(sectionsOf(result.song), ["Intro", "Verse 1", "Chorus", "Bridge"]);
  assert.deepEqual(commentsOf(result.song), ["Ann B", "Ann B & Cal", "Cal & Ann B"]);
  assert.deepEqual(chordsOf(result.song), [], "no section label may ever appear as a chord");
});

test("the section count equals the number of bracketed headers", () => {
  const { result } = lyricsOnly("count.txt", WITH_PERFORMERS);
  const headers = WITH_PERFORMERS.split("\n").filter((l) => /^\[.*\]$/.test(l)).length;
  assert.equal(sectionsOf(result.song).length, headers);
});

test("lyrics-only text whose headers have no performers loads the same way", () => {
  const plain = WITH_PERFORMERS.replace(/: [^\]]*\]/g, "]");
  const { result } = lyricsOnly("plain.txt", plain);
  assert.deepEqual(result.problems, []);
  assert.deepEqual(sectionsOf(result.song), ["Intro", "Verse 1", "Chorus", "Bridge"]);
  assert.deepEqual(commentsOf(result.song), []);
  assert.deepEqual(chordsOf(result.song), []);
});

test("a two-word lyric line such as an ad-lib credit stays a lyric", () => {
  const lyrics = ["[Verse 1: Ann B]", "Made up line", "Ann B", "", "[Chorus: Cal]", "Pretend line"].join("\n");
  const { result } = lyricsOnly("adlib.txt", lyrics);
  assert.deepEqual(result.problems, []);
  assert.deepEqual(chordsOf(result.song), []);
  assert.ok(lyricLinesOf(result.song).includes("Ann B"));
});

test("a header with a name in it is not read as chords by the other readers", () => {
  const lyrics = ["[Verse 1: Ann B]", "Made up line", "Ann B", "", "[Chorus: Cal]", "Pretend line"].join("\n");
  for (const format of ["chordpro", "chords-over-words", "ultimate-guitar"]) {
    const { code, result } = load(file(`names-${format}.txt`, lyrics), "--format", format);
    if (code === 0) assert.deepEqual(chordsOf(result.song).filter((c) => /[a-z]{3,}/.test(c)), [], format);
  }
});

test("bare chord letters as headers do not break a chord sheet", () => {
  const sheet = "[Verse A]\nAm       C\nSome invented words here\n\n[B]\nG        D\nMore invented words\n";
  const { result } = load(file("letters.txt", sheet));
  assert.deepEqual(result.problems, []);
  assert.deepEqual(sectionsOf(result.song), ["Verse A", "B"]);
  assert.deepEqual(chordsOf(result.song), ["Am", "C", "G", "D"]);
});

test("check fails when a header has been turned into a chord", () => {
  const path = file("headers.txt", "[Verse 1: Ann B]\nMade up line\n\n[Chorus: Cal]\nPretend line\n");
  const song = JSON.parse(run("parse.mjs", [path, "--format", "lyrics-only"]).stdout);
  // damage the song the way a chord reader would: every header becomes a "chord" and the sections are gone
  const damaged = { type: "chordSheet", lines: song.lines
    .filter((l) => !(l.items.length === 1 && l.items[0].type === "tag"))
    .map((l, i) => (i % 3 === 0 ? { type: "line", items: [{ type: "chordLyricsPair", chords: i === 0 ? "Verse 1: Ann B" : "Chorus: Cal", chord: null, lyrics: "", annotation: "" }] } : l)) };
  const checked = run("check.mjs", ["--original", path], JSON.stringify(damaged));
  assert.equal(checked.status, 1);
  const kinds = JSON.parse(checked.stdout).problems.map((p) => p.kind);
  assert.ok(kinds.includes("not-a-chord"));
  assert.ok(kinds.includes("sections-missing"));
});

test("ChordPro text with [Header] lines reads the headers as sections and the inline chords as chords", () => {
  const sheet = "[Verse 1: Ann B]\n[Am]Made up [C]line\nPretend [G]line\n\n[Chorus]\n[F]More invented words\n";
  const { code, result } = load(file("hybrid.txt", sheet));
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  assert.deepEqual(sectionsOf(result.song), ["Verse 1", "Chorus"]);
  assert.deepEqual(chordsOf(result.song), ["Am", "C", "G", "F"]);
});

test("a bar mark touching a chord is a mark of its own", () => {
  const sheet = "[Verse 1]\n| G#m7 | Emaj7| Emaj7 |\nMade up line\n";
  const { code, result } = load(file("pipes.txt", sheet));
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  assert.ok(chordsOf(result.song).filter((c) => c === "Emaj7").length === 2);
});

test("check fails when an ordinary word is read as a chord", () => {
  const path = file("word.txt", "[Verse 1]\nMade up line\nAnn B\n\n[Chorus]\nPretend line\n");
  const parsed = run("parse.mjs", [path, "--format", "ultimate-guitar"]);
  const checked = run("check.mjs", ["--original", path], parsed.stdout);
  assert.equal(checked.status, 1);
  assert.ok(JSON.parse(checked.stdout).problems.some((p) => p.kind === "not-a-chord"));
});

test("a changed word, a lost line and an added line are all caught", () => {
  const path = file("three.txt", "One two three\nFour five six\nSeven eight nine\n");
  const song = JSON.parse(run("parse.mjs", [path]).stdout);
  const lyric = (l) => l.items[0].lyrics;
  const changed = structuredClone(song);
  changed.lines[0].items[0].lyrics = lyric(song.lines[0]).replace("two", "2");
  const lost = structuredClone(song);
  lost.lines.splice(1, 1);
  const added = structuredClone(song);
  added.lines.splice(1, 0, { type: "line", items: [{ type: "chordLyricsPair", chords: "", chord: null, lyrics: "Invented extra", annotation: "" }] });
  for (const [name, damaged, kind] of [["changed", changed, "changed"], ["lost", lost, "missing"], ["added", added, "extra"]]) {
    const r = run("check.mjs", ["--original", path], JSON.stringify(damaged));
    assert.equal(r.status, 1, name);
    assert.ok(JSON.parse(r.stdout).problems.some((p) => p.kind === kind), name);
  }
});

test("spacing does not matter to the check but joined words do", () => {
  const original = file("spaced.txt", "Hello   world\n    Second line  \n");
  const same = run("parse.mjs", [file("tidy.txt", "Hello world\nSecond line\n")]).stdout;
  assert.equal(run("check.mjs", ["--original", original], same).status, 0);
  const joined = run("parse.mjs", [file("joined.txt", "Helloworld\nSecond line\n")]).stdout;
  assert.equal(run("check.mjs", ["--original", original], joined).status, 1);
});

test("chords above words keep their words, positions and names", () => {
  const sheet = "[Verse 1]\nEbmaj7     Gm\nInvented words here\n";
  const parsed = run("parse.mjs", [file("chords.txt", sheet)]);
  const out = run("format.mjs", ["--as", "chords-over-words"], parsed.stdout).stdout;
  assert.match(out, /Ebmaj7/, "the chord name is written as read, not as Ebma7");
  assert.equal(run("check.mjs", ["--original", file("chords2.txt", sheet)], parsed.stdout).status, 0);
});

test("set-aside takes title lines out, and check needs to be told", () => {
  const path = file("titled.txt", "Invented Title\nWords and Music: Ann B - 1 May 2020\n\n[Verse 1]\nMade up line\n");
  const parsed = run("parse.mjs", [path]).stdout;
  const aside = run("set-aside.mjs", ["--original", path, "--lines", "1,2"], parsed);
  assert.equal(aside.status, 0);
  assert.equal(run("check.mjs", ["--original", path], aside.stdout).status, 1, "the credit line is missing unless declared");
  assert.equal(run("check.mjs", ["--original", path, "--set-aside", "1,2"], aside.stdout).status, 0);
  assert.equal(run("set-aside.mjs", ["--original", path, "--lines", "4"], parsed).status, 1, "a header is not a lyric line");
});

test("load reports missing facts as questions, and never asks for copyright", () => {
  const { result } = load(file("nofacts.txt", "[Verse 1]\nMade up line\n"));
  assert.equal(result.status, "needs-info");
  assert.deepEqual(result.missing, ["title", "credits", "date"]);
  assert.equal(result.questions.length, 3);
  assert.ok(!result.questions.join(" ").toLowerCase().includes("copyright"));
});

test("load fails cleanly on a broken ChordPro file and gives the line", () => {
  const { code, result } = load(file("broken.cho", "{title: T}\n\n[Am]Line one\n{start_of_verse: V1\nLine [C]three\n"));
  assert.equal(code, 1);
  assert.equal(result.status, "failed");
  assert.match(result.problems[0].message, /line 4/);
});

test("load puts the facts and the written song into one result", () => {
  const path = file("full.txt", "[Verse 1]\nMade up line\n");
  const facts = file("facts.json", JSON.stringify({ title: "Invented", artist: "Ann B", date: "2020" }));
  const { result } = load(path, "--facts", facts, "--as", "chordpro");
  assert.equal(result.status, "ok");
  assert.match(result.output, /\{title: Invented\}/);
});

// ---- Word files: built here from invented paragraphs ------------------------------------------------

const crcTable = Array.from({ length: 256 }, (_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
const crc32 = (buf) => {
  let c = 0xffffffff;
  for (const byte of buf) c = crcTable[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
};
function zip(entries) {
  const parts = [];
  const central = [];
  let offset = 0;
  for (const e of entries) {
    const name = Buffer.from(e.name);
    const raw = Buffer.from(e.data);
    const body = e.deflate ? deflateRawSync(raw) : raw;
    const method = e.deflate ? 8 : 0;
    const crc = crc32(raw);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(method, 8);
    local.writeUInt32LE(crc, 14); local.writeUInt32LE(body.length, 18); local.writeUInt32LE(raw.length, 22);
    local.writeUInt16LE(name.length, 26);
    parts.push(local, name, body);
    const head = Buffer.alloc(46);
    head.writeUInt32LE(0x02014b50, 0); head.writeUInt16LE(20, 4); head.writeUInt16LE(20, 6); head.writeUInt16LE(method, 10);
    head.writeUInt32LE(crc, 16); head.writeUInt32LE(body.length, 20); head.writeUInt32LE(raw.length, 24);
    head.writeUInt16LE(name.length, 28); head.writeUInt32LE(offset, 42);
    central.push(head, name);
    offset += 30 + name.length + body.length;
  }
  const directory = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(directory.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...parts, directory, end]);
}

const para = (inner) => `<w:p><w:r>${inner}</w:r></w:p>`;
const documentXml = `<?xml version="1.0"?><w:document xmlns:w="w"><w:body>
${para("<w:t>Invented Title</w:t>")}
${para("<w:t>Words &amp; Music: Ann B</w:t>")}
<w:p/>
${para("<w:t>[Verse 1]</w:t>")}
<w:p><w:r><w:t xml:space="preserve">Made up</w:t></w:r><w:r><w:tab/></w:r><w:r><w:t>line</w:t></w:r><w:del w:id="1"><w:r><w:delText>gone words</w:delText></w:r></w:del><w:ins w:id="2"><w:r><w:t> kept words</w:t></w:r></w:ins></w:p>
<w:p><w:pPr><w:rPr><w:del w:id="3" w:author="x"/></w:rPr></w:pPr><w:r><w:t>Second line it&apos;s here</w:t></w:r></w:p>
${para("<w:t>Third line after a deleted mark</w:t>")}
</w:body></w:document>`;
const commentsXml = `<w:comments xmlns:w="w"><w:comment w:id="0"><w:p><w:r><w:t>SECRET COMMENT</w:t></w:r></w:p></w:comment></w:comments>`;
const docx = (name, deflate) =>
  file(name, zip([
    { name: "[Content_Types].xml", data: "<Types/>", deflate },
    { name: "word/document.xml", data: documentXml, deflate },
    { name: "word/comments.xml", data: commentsXml, deflate },
  ]));

for (const [label, deflate] of [["stored", false], ["compressed", true]]) {
  test(`a Word file (${label} zip) loads as its paragraph text only`, () => {
    const { code, result } = load(docx(`song-${label}.docx`, deflate));
    assert.equal(code, 0);
    assert.deepEqual(result.problems, []);
    assert.deepEqual(result.source, { type: "word" });
    const lyrics = lyricLinesOf(result.song).join("\n");
    assert.match(lyrics, /Made up line kept words/, "text, a tab as a space, inserted text kept");
    assert.doesNotMatch(lyrics, /gone words/, "deleted text is ignored");
    assert.doesNotMatch(JSON.stringify(result), /SECRET COMMENT/, "comments are ignored");
    assert.match(lyrics, /Second line it's here/, "entities are decoded");
    assert.match(lyrics, /Third line after a deleted mark/, "a deleted paragraph mark does not swallow what follows");
    assert.deepEqual(sectionsOf(result.song), ["Verse 1"]);
  });
}

test("a zip that is not a Word file fails with a plain message", () => {
  const path = file("not-word.docx", zip([{ name: "readme.txt", data: "hello" }]));
  const { code, result } = load(path);
  assert.equal(code, 1);
  assert.equal(result.status, "failed");
  assert.match(result.problems[0].message, /not a Word/);
});

test("a plain text file with a .docx name is read as text", () => {
  const { result } = load(file("really-text.docx", "[Verse 1]\nMade up line\n"));
  assert.deepEqual(sectionsOf(result.song), ["Verse 1"]);
});

// ---- Labels without brackets, and chord lines the library cannot read --------------------------------

test("section labels without brackets become sections and keep their chords, bar lines included", () => {
  const sheet = [
    "Invented Title", "", "V1", "| Ebmin7 | Db6/F Db |", "Am       C", "Some invented words here", "",
    "CHORUS", "G        D", "More invented words", "", "Bridge", "| Am | G |",
  ].join("\n");
  const { code, result } = load(file("bare.txt", sheet));
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  assert.deepEqual(sectionsOf(result.song), ["V1", "CHORUS", "Bridge"]);
  assert.deepEqual(chordsOf(result.song).filter((c) => c !== "|"), ["Ebmin7", "Db6/F", "Db", "Am", "C", "G", "D", "Am", "G"]);
});

test("a lyric line that merely starts like a label is not made a section", () => {
  const sheet = "Am       C\nChorus of invented birds\n\nV1\nMade up line\n";
  const { result } = load(file("labelish.txt", sheet));
  assert.deepEqual(sectionsOf(result.song), ["V1"]);
});

test("a chord line with a chord the library does not know is still read as chords", () => {
  const sheet = "[Verse 1]\n|    Amin     |   D/F#   G(maj7) |\nSome invented words here\n";
  const { code, result } = load(file("odd-chord.txt", sheet));
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  const chords = chordsOf(result.song);
  assert.ok(chords.includes("G(maj7)") && chords.includes("D/F#") && chords.includes("Amin"), chords.join(" "));
  const lyrics = lyricLinesOf(result.song).join("\n");
  assert.doesNotMatch(lyrics, /G\(maj7\)/, "the chord line is not left among the lyrics");
});

test("a chord line on its own, with no lyric below, is kept as chords", () => {
  const { code, result } = load(file("alone.txt", "[Intro]\n| Amin | D/F# G(maj7) |\n\n[Verse 1]\nMade up line\n"));
  assert.equal(code, 0);
  assert.ok(chordsOf(result.song).includes("G(maj7)"));
});

// ---- Saving a readable copy ----------------------------------------------------------------------------

test("--save writes a readable file named from the title and artist, and never replaces one", () => {
  const folder = join(dir, "saved");
  const path = file("save-me.txt", "[Verse 1]\nAm       C\nMade up words here\n");
  const facts = file("save-facts.json", JSON.stringify({ title: "Invented: Song?", artist: "Ann B", date: "2020" }));
  const first = load(path, "--facts", facts, "--save", folder).result;
  assert.equal(first.status, "ok");
  assert.match(first.savedTo, /Invented Song - Ann B\.txt$/, "characters a file name cannot hold are removed");
  const text = readFileSync(first.savedTo, "utf8");
  assert.match(text, /Am/, "chords are kept when the song has chords");
  assert.match(text, /Made up words here/);
  const second = load(path, "--facts", facts, "--save", folder).result;
  assert.match(second.savedTo, /Invented Song - Ann B \(2\)\.txt$/, "an existing file is not replaced");
  assert.equal(readFileSync(first.savedTo, "utf8"), text, "and is left as it was");
});

test("--save writes plain text when the song has no chords", () => {
  const folder = join(dir, "saved-plain");
  const { result } = load(file("plain-save.txt", "[Verse 1]\nMade up words here\n"), "--save", folder);
  assert.match(result.savedTo, /song\.txt$/, "a song with no title or artist is called song");
  assert.doesNotMatch(readFileSync(result.savedTo, "utf8"), /^[A-G][a-z0-9#]*\s*$/m);
});

test("--open needs --save", () => {
  const r = run("load.mjs", [file("open-alone.txt", "One line\n"), "--open"]);
  assert.equal(r.status, 2);
  assert.match(r.stderr, /--open needs --save/);
});

test("--save default goes to Documents, then Desktop, then the home folder", () => {
  const sheet = file("default-save.txt", "[Verse 1]\nMade up words here\n");
  const attempt = (home) => {
    const r = spawnSync(process.execPath, [join(scripts, "load.mjs"), sheet, "--save", "default"], {
      encoding: "utf8", env: { ...process.env, HOME: home, USERPROFILE: home },
    });
    return JSON.parse(r.stdout).savedTo;
  };
  const withBoth = join(dir, "home1");
  mkdirSync(join(withBoth, "Documents"), { recursive: true });
  mkdirSync(join(withBoth, "Desktop"), { recursive: true });
  assert.equal(attempt(withBoth), join(withBoth, "Documents", "song.txt"));
  const desktopOnly = join(dir, "home2");
  mkdirSync(join(desktopOnly, "Desktop"), { recursive: true });
  assert.equal(attempt(desktopOnly), join(desktopOnly, "Desktop", "song.txt"));
  const bare = join(dir, "home3");
  mkdirSync(bare, { recursive: true });
  assert.equal(attempt(bare), join(bare, "song.txt"));
});

// ---- A sample lyric (Ballad of Lorem Ipsum): labels without brackets, a title line, a repeat mark --------

const EXAMPLES = fileURLToPath(new URL("../examples/", import.meta.url));
const LOREM = join(EXAMPLES, "3-labels-without-brackets.txt");

test("the Lorem Ipsum sample loads as six sections, and its title line is a lyric until set aside", () => {
  const { code, result } = load(LOREM);
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  assert.deepEqual(sectionsOf(result.song), ["Verse 1", "Chorus", "Verse 2", "Bridge", "Chorus", "Outro"]);
  assert.equal(result.status, "needs-info");
  assert.deepEqual(result.missing, ["title", "credits", "date"]);
  const beforeFirstSection = result.song.lines.slice(0, result.song.lines.findIndex((l) => l.items.some((x) => x.name === "start_of_verse")));
  assert.ok(beforeFirstSection.some((l) => l.items.some((x) => x.lyrics === "Ballad of Lorem Ipsum")));
});

test("the Lorem Ipsum sample with its title set aside has the title as a fact and asks for credits and date", () => {
  const facts = file("lorem-facts.json", JSON.stringify({ title: "Ballad of Lorem Ipsum" }));
  const { result } = load(LOREM, "--facts", facts, "--set-aside", "1");
  assert.deepEqual(result.problems, []);
  assert.deepEqual(result.missing, ["credits", "date"]);
  assert.equal(result.questions.length, 2);
  assert.ok(!lyricLinesOf(result.song).includes("Ballad of Lorem Ipsum"), "the title is no longer a lyric line");
});

test("the Lorem Ipsum sample keeps its curly apostrophes and its (repeat) line exactly", () => {
  const { result } = load(LOREM);
  const lyrics = lyricLinesOf(result.song);
  assert.ok(lyrics.includes("You\u2019re welcome to scramble"));
  assert.ok(lyrics.includes("He\u2019d ruin something flawless"));
  assert.ok(lyrics.includes("(repeat)"), "a repeat mark is a lyric line; the skill does not interpret it");
  assert.equal(lyrics.length, 19, "every line is kept: the title line, 17 sung lines and the repeat mark");
});

// ---- The examples folder: one lyric written five ways -----------------------------------------------------

test("the examples folder: each way of writing the lyric loads without problems", () => {
  const six = ["Verse 1", "Chorus", "Verse 2", "Bridge", "Chorus", "Outro"];
  const pasted = JSON.parse(run("load.mjs", ["-"], readFileSync(join(EXAMPLES, "1-pasted-text.txt"), "utf8")).stdout);
  assert.equal(pasted.status, "needs-info");
  assert.deepEqual(pasted.problems, []);
  assert.deepEqual(sectionsOf(pasted.song), [], "stanzas with no labels have no sections");
  for (const name of ["2-bracket-headers.txt", "3-labels-without-brackets.txt", "4-chordpro.cho", "5-chords-above-words.txt"]) {
    const { code, result } = load(join(EXAMPLES, name));
    assert.equal(code, 0, name);
    assert.deepEqual(result.problems, [], name);
    assert.deepEqual(sectionsOf(result.song), six, name);
  }
});

test("the examples with chords have the same 16 chords", () => {
  const a = chordsOf(load(join(EXAMPLES, "4-chordpro.cho")).result.song);
  const b = chordsOf(load(join(EXAMPLES, "5-chords-above-words.txt")).result.song);
  assert.equal(a.length, 16);
  assert.deepEqual(a, b);
});

// ---- A parse failure explained for a writer ---------------------------------------------------------------

test("an unclosed [ is named on its own line, with the file name and how sure we are", () => {
  const { code, result } = load(file("Odd bar.pro", "{title: Invented}\n\nInterlude\n[Am | G | C |\n\nSome invented words\n"));
  assert.equal(code, 1);
  assert.equal(result.status, "failed");
  const message = result.problems[0].message;
  assert.match(message, /^In Odd bar\.pro: Line 4 has a "\[" that is never closed with "\]"\. This is very likely the problem\./);
  assert.match(message, /line 4: \[Am \| G \| C \|/, "the line is shown");
  assert.doesNotMatch(message, /^note:/m, "progress notes are left out");
});

test("an unclosed { in pasted text gives a message with no file name", () => {
  const ran = run("load.mjs", ["-"], "Some words\n\n{title: x\nmore invented words\n");
  const message = JSON.parse(ran.stdout).problems[0].message;
  assert.match(message, /^Line 3 has a "\{" that is never closed with "\}"/);
});

test("a file that cannot be read gives a plain message that says what to do", () => {
  const message = (path) => load(path).result.problems[0].message;
  assert.match(message(join(dir, "no-such-file.txt")), /there is no file with that name\. Check the name and the folder\./);
  assert.match(message(file("Empty song.txt", "  \n\n")), /^"Empty song\.txt" is empty, or has only blank lines/);
  assert.match(message(file("Song.pdf", "%PDF-1.4\nbinary")), /^"Song\.pdf" is a PDF\. .*paste the text\.$/);
  assert.match(message(file("Song.rtf", "{\\rtf1\\ansi Invented words}")), /is a Rich Text \(\.rtf\) file/);
  assert.match(message(dir), /that is a folder, not a file\./);
});

// ---- Unbracketed "Label: Performer" headers (bug report, 10 Oct 2026) -------------------------------------

const performerSheet =
  "title: Invented Song\nartist: Someone\n\nVerse 1: Singer A\nfirst line here\nsecond line here\n\nPre-Chorus: Singer A\nthird line here\n\n" +
  "Chorus: Singer B\nfourth line here\n\nOutro: Singer B\nlast line here\n";

test("headers written as 'Label: Performer' without brackets become sections, with the performer as a comment", () => {
  const { code, result } = load(file("performers.txt", performerSheet));
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  assert.deepEqual(sectionsOf(result.song), ["Verse 1", "Pre-Chorus", "Chorus", "Outro"]);
  assert.deepEqual(commentsOf(result.song), ["Singer A", "Singer A", "Singer B", "Singer B"]);
  assert.equal(lyricLinesOf(result.song).length, 5, "the five sung lines, and no header kept as a lyric");
});

test("check says so when a header written without brackets has no section in the song", () => {
  const original = file("headers-lost.txt", "Verse 1: Singer A\nfirst line here\n\nChorus: Singer B\nsecond line here\n");
  const flat = run("parse.mjs", [file("flat.txt", "first line here\nsecond line here\n"), "--format", "lyrics-only"]).stdout;
  const checked = JSON.parse(run("check.mjs", ["--original", original], flat).stdout);
  assert.ok(checked.problems.some((p) => p.kind === "sections-missing" && p.headersInOriginal === 2), JSON.stringify(checked.problems));
});

const lyricsOnlyOf = (path, ...extra) => load(path, "--as", "lyrics-only", ...extra).result;

test("--as lyrics-only: facts first, then one block per section with [Label: Performer], no facts inside", () => {
  const result = lyricsOnlyOf(file("performers2.txt", performerSheet));
  assert.equal(
    result.output,
    "Title: Invented Song\nArtist: Someone\n\n[Verse 1: Singer A]\nfirst line here\nsecond line here\n\n[Pre-Chorus: Singer A]\nthird line here\n\n" +
      "[Chorus: Singer B]\nfourth line here\n\n[Outro: Singer B]\nlast line here\n",
  );
});

test("--as lyrics-only: a chords-only section is its [Label] alone, and chords, bars, marks and comments are left out", () => {
  const sheet = "{title: Invented Demo}\n{key: D minor}\n\n{start_of_part: Intro}\n[Am] [G]\n{end_of_part}\n\n" +
    "{start_of_verse: Verse 1}\n[Am]First invented  line\n{comment: repeat}\n[G]Second invented line\n{end_of_verse}\n";
  const result = lyricsOnlyOf(file("chords-only-intro.cho", sheet));
  assert.equal(result.output, "Title: Invented Demo\nKey: D minor\n\n[Intro]\n\n[Verse 1]\nFirst invented line\nSecond invented line\n");
});

test("--as lyrics-only: lines outside any section come first, under no header, with their stanza break", () => {
  const result = lyricsOnlyOf(file("loose.txt", "Loose invented one\nLoose invented two\n\nLoose invented three\n"));
  assert.equal(result.output, "Loose invented one\nLoose invented two\n\nLoose invented three\n");
});

for (const [label, make] of [
  ["a chords-above-words file", () => join(EXAMPLES, "5-chords-above-words.txt")],
  ["a ChordPro file", () => join(EXAMPLES, "4-chordpro.cho")],
  ["pasted text", () => join(EXAMPLES, "1-pasted-text.txt")],
  ["a Word file", () => docx("lyrics-only.docx", true)],
]) {
  test(`--as lyrics-only on ${label}: the lyric lines are those of the checked song, word for word`, () => {
    const result = lyricsOnlyOf(make());
    assert.notEqual(result.status, "failed");
    const squash = (t) => t.replace(/\s+/g, " ").trim();
    const wanted = lyricLinesOf(result.song).map(squash).filter(Boolean);
    const written = result.output.split("\n").filter((l) => l.trim() && !/^\[.*\]$/.test(l) && !/^[A-Z][a-z]+: /.test(l)).map(squash);
    // facts like "Title: x" are written as lines of their own, so leave them out of the comparison
    assert.deepEqual(written.slice(-wanted.length), wanted);
    assert.doesNotMatch(result.output, /^[A-G][#b]?(m|maj|min|sus|add)?\d*(\/[A-G])?(\s|$)/m, "no chord lines");
  });
}

test("--as lyrics-only never writes a song that fails the check", () => {
  const { code, result } = load(file("fails.txt", "{title: x\nmore words\n"), "--as", "lyrics-only");
  assert.equal(code, 1);
  assert.equal(result.output, undefined);
});

test("Word's temporary lock files (~$name.docx) are refused in plain words, not read as a song", () => {
  const message = load(file("~$Invented.docx", "\u0003Word lock file\u0000\u0000")).result.problems[0].message;
  assert.match(message, /does not look like a text file/);
});

test("text with inline chords, labels without brackets and a bracketed bar line keeps sections and chords", () => {
  const sheet =
    "INTRO\n[Am | G/B]\n\nVERSE 1\n\n[Am] First invented line\n[G/B] Second invented line\n\nCHORUS\n\n[C] Third invented line\n";
  const { code, result } = load(file("mixed.txt", sheet));
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  assert.deepEqual(sectionsOf(result.song), ["INTRO", "VERSE 1", "CHORUS"]);
  assert.ok(chordsOf(result.song).includes("Am | G/B"), "the bar line is chords, not a section title");
});

test("a bar line whose closing ] is missing is named by line in the message", () => {
  const sheet = "INTRO\n[Am | G/B\n\nVERSE 1\n\n[Am] First invented line\n";
  const { result } = load(file("unclosed-bar.txt", sheet));
  assert.equal(result.status, "failed");
  assert.match(result.problems[0].message, /Line 2 has a "\[" that is never closed/);
});

// ---- Bar charts, headers with a note, held chords (bug report for 0.1.2, 15 Oct 2026) -----------------------

const barSheet =
  "[VERSE 1]\n|  G  |   G  |  D  | D   |\n|  C  |  C  |  G  | D C |\nEarly invented morning\nSecond invented line\n\n" +
  "[INSTRUMENTAL / SOLO]\n|  G  |  D  |\n\n[VERSE 5] (sung quietly, intimately)\nA quiet invented line\n\n" +
  "[OUTRO]\n|  -  |  C  |\n|  C   |  G …  |\nLast invented line\n";
const pairsOf = (song) => song.lines.flatMap((l) => l.items.filter((x) => x.type === "chordLyricsPair"));

test("bar-chart lines stay chord-only lines; the lyric below is left as plain words", () => {
  const { code, result } = load(file("bars.txt", barSheet));
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  for (const words of ["Early invented morning", "Last invented line"]) {
    const pair = pairsOf(result.song).filter((x) => x.lyrics === words);
    assert.equal(pair.length, 1, `${words} is one plain pair`);
    assert.equal(pair[0].chords, "", `${words} has no chord on it`);
  }
  assert.equal(chordsOf(result.song).filter((c) => c === "|").length, 19, "every bar mark is kept");
});

test("a header with a note in ( ) after it is a header, and the note is a comment", () => {
  const { result } = load(file("note-header.txt", barSheet));
  assert.deepEqual(sectionsOf(result.song), ["VERSE 1", "INSTRUMENTAL / SOLO", "VERSE 5", "OUTRO"]);
  assert.deepEqual(commentsOf(result.song), ["sung quietly, intimately"]);
  assert.ok(result.notes.some((n) => /header\(s\) with a note/.test(n)));
});

test("a hold mark after a chord keeps the chord and is written back as it was", () => {
  const sheet = "[OUTRO]\n|  C  |  G …  | D… | A.. |\nLast invented line\n";
  const { code, result } = load(file("hold.txt", sheet), "--as", "chords-over-words");
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  assert.deepEqual(chordsOf(result.song).filter((c) => c !== "|"), ["C", "G …", "D…", "A.."]);
  assert.match(result.output, /\| C \| G … \| D… \| A\.\. \|/);
});

test("facts written after the last lyric line are moved up with the other facts", () => {
  const sheet = "title: Invented Song\n\n[Verse 1]\nFirst invented line\n\n[Outro]\nLast invented line\nAcknowledgements: Someone Invented\n";
  const { code, result } = load(file("trailing-facts.txt", sheet));
  assert.equal(code, 0);
  assert.deepEqual(result.problems, []);
  const names = result.song.lines.flatMap((l) => l.items.filter((x) => x.type === "tag").map((x) => x.name));
  assert.deepEqual(names.slice(0, 2), ["title", "Acknowledgements"], "the fact sits with the title, before the first section");
  assert.equal(names.filter((n) => n === "Acknowledgements").length, 1);
  assert.deepEqual(sectionsOf(result.song), ["Verse 1", "Outro"]);
  assert.ok(result.notes.some((n) => /fact line\(s\) after the last lyric line/.test(n)));
});

// ---- Plain messages for a failed check -----------------------------------------------------------------------

test("every problem from a failed load has a plain message with the line, and the messages do not teach one typo", () => {
  const sheets = {
    chordTypo: "[VERSE 1]\n|  F  C/F  |  Dmin/F  C /F  |  x2\nFirst invented line\n",
    wordInChordLine: "[VERSE 1]\nIntro | Gm79 | C7\nFirst invented line\n",
    unknownSymbol: "[VERSE 1]\n|  F  |  C§  |  G  |\nFirst invented line\n",
  };
  for (const [name, sheet] of Object.entries(sheets)) {
    const { result } = load(file(`${name}.txt`, sheet));
    if (result.status !== "failed") continue; // a sheet the skill reads fine needs no message
    assert.ok(result.problems.length > 0, name);
    for (const p of result.problems) {
      assert.equal(typeof p.message, "string", `${name}: every problem has a message`);
      assert.doesNotMatch(p.message, /@@CHORDLINE|undefined|\[object/, `${name}: no internal text in a message`);
      assert.doesNotMatch(p.message, /for example|written instead of/i, `${name}: no example is tied to one typo`);
    }
    const lines = result.problems.filter((p) => p.kind === "missing" || p.kind === "changed");
    assert.ok(lines.some((p) => new RegExp(`Line ${p.line ?? ""}`).test(p.message) || /Line \d+/.test(p.message)), `${name}: names a line`);
  }
});

test("a missing line is quoted in its message with the line number", () => {
  const { result } = load(file("quoted.txt", "[VERSE 1]\n|  F  C/F  |  Dmin/F  C /F  |  x2\nFirst invented line\n"));
  assert.equal(result.status, "failed");
  const missing = result.problems.find((p) => p.kind === "missing");
  assert.match(missing.message, /^Line 2, "\| F C\/F \| Dmin\/F C \/F \| x2", was left out of the result\./);
  assert.match(missing.message, /Look at the line for anything unusual/);
});

// A chord chart in front of the lyrics (invented samples in tests/samples/charts/).
const chartSample = (name) => fileURLToPath(new URL(`./samples/charts/${name}`, import.meta.url));

test("a Chords heading, chord rows and a Lyrics heading make a chart that is set aside, with line numbers kept", () => {
  const { code, result } = load(chartSample("chart-with-headings.txt"));
  assert.equal(code, 0);
  assert.deepEqual([result.chart.from, result.chart.to], [3, 9]);
  assert.ok(result.chart.text.includes("| Am") && result.chart.text.includes("2x repeat"));
  assert.ok(result.setAside.some((l) => l.startsWith("lines 3-9")));
  assert.ok(result.notes.some((n) => n.includes("lines 3-9 are a chord chart")));
  assert.deepEqual(lyricLinesOf(result.song).slice(-2), ["Some invented words here", "Another invented line"]);
  assert.ok(!lyricLinesOf(result.song).some((t) => /Chart|VERSES|repeat|Lyrics$/.test(t)), "no chart text is left in the lyrics");
  assert.ok(!result.questions.some((q) => /chord chart/.test(q)), "a clear chart is not asked about");
});

test("a Chords heading with no Lyrics heading after it leaves the song as the readers get it", () => {
  const { result } = load(chartSample("chords-heading-only.txt"));
  assert.equal(result.chart, undefined);
  assert.ok(!result.questions.some((q) => /chord chart/.test(q)));
});

test("four chord rows before any lyric, with no headings, are asked about and nothing is changed", () => {
  const { result } = load(chartSample("chart-no-headings.txt"));
  assert.equal(result.chart, undefined);
  assert.equal(result.status, "needs-info");
  assert.ok(result.questions[0].startsWith("Lines 3 to 6 look like a chord chart"));
  assert.ok(result.song.lines.some((l) => l.items.some((x) => x.chords === "Dm")), "the chords are still in the song");
});

test("--chart sets the lines aside as a chart, and --keep-chart keeps them and does not ask", () => {
  const set = load(chartSample("chart-no-headings.txt"), "--chart", "3-6").result;
  assert.deepEqual([set.chart.from, set.chart.to], [3, 6]);
  assert.ok(!set.questions.some((q) => /chord chart/.test(q)));
  assert.ok(!set.song.lines.some((l) => l.items.some((x) => x.chords === "Dm")));
  const kept = load(chartSample("chart-no-headings.txt"), "--keep-chart").result;
  assert.equal(kept.chart, undefined);
  assert.ok(!kept.questions.some((q) => /chord chart/.test(q)));
});

test("--chart must be a range of line numbers", () => {
  const r = run("load.mjs", [chartSample("chart-no-headings.txt"), "--chart", "x"]);
  assert.equal(r.status, 2);
  assert.match(r.stderr, /--chart must be a range/);
});

test("a chord-only intro that sits among lyrics is not mistaken for a chart", () => {
  const text = ["Invented Song", "", "[Intro]", "| Am | F |", "| C | G |", "", "[Verse 1]", "Some invented words here today", "| Am | F |", "More invented words go here"].join("\n");
  const { result } = load(file("intro-among-lyrics.txt", text));
  assert.equal(result.chart, undefined);
  assert.ok(!result.questions.some((q) => /chord chart/.test(q)));
});
